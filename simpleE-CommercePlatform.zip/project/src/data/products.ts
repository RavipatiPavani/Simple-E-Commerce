import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 299.99,
    description: "High-quality wireless headphones with noise cancellation and 30-hour battery life.",
    image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Electronics",
    rating: 4.8,
    reviews: 1247,
    inStock: true,
    features: ["Active Noise Cancellation", "30-hour Battery", "Quick Charge", "Premium Build Quality"]
  },
  {
    id: 2,
    name: "Smart Fitness Watch",
    price: 399.99,
    description: "Advanced fitness tracking with heart rate monitor, GPS, and smartphone connectivity.",
    image: "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Electronics",
    rating: 4.6,
    reviews: 892,
    inStock: true,
    features: ["Heart Rate Monitor", "GPS Tracking", "Water Resistant", "7-day Battery"]
  },
  {
    id: 3,
    name: "Organic Cotton T-Shirt",
    price: 39.99,
    description: "Soft, sustainable organic cotton t-shirt available in multiple colors and sizes.",
    image: "https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Clothing",
    rating: 4.4,
    reviews: 324,
    inStock: true,
    features: ["100% Organic Cotton", "Machine Washable", "Pre-shrunk", "Fair Trade"]
  },
  {
    id: 4,
    name: "Professional Camera Lens",
    price: 899.99,
    description: "Professional 85mm f/1.4 portrait lens with exceptional image quality and bokeh.",
    image: "https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Photography",
    rating: 4.9,
    reviews: 567,
    inStock: false,
    features: ["85mm f/1.4", "Professional Grade", "Weather Sealed", "Image Stabilization"]
  },
  {
    id: 5,
    name: "Minimalist Desk Lamp",
    price: 149.99,
    description: "Sleek LED desk lamp with adjustable brightness and wireless charging base.",
    image: "https://images.pexels.com/photos/1094767/pexels-photo-1094767.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Home",
    rating: 4.7,
    reviews: 445,
    inStock: true,
    features: ["LED Technology", "Wireless Charging", "Touch Controls", "Energy Efficient"]
  },
  {
    id: 6,
    name: "Artisan Coffee Beans",
    price: 24.99,
    description: "Single-origin coffee beans roasted to perfection with notes of chocolate and caramel.",
    image: "https://images.pexels.com/photos/894695/pexels-photo-894695.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Food",
    rating: 4.8,
    reviews: 234,
    inStock: true,
    features: ["Single Origin", "Medium Roast", "Fair Trade", "Fresh Roasted"]
  }
];