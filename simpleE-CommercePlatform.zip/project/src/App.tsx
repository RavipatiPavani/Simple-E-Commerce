import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ProductGrid from './components/ProductGrid';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import AuthModal from './components/AuthModal';
import CheckoutModal from './components/CheckoutModal';
import OrderHistory from './components/OrderHistory';
import { useAuth } from './hooks/useAuth';
import { useCart } from './hooks/useCart';
import { useOrders } from './hooks/useOrders';
import { products } from './data/products';
import { Product, Order } from './types';

type View = 'products' | 'product-detail' | 'orders';

function App() {
  const [currentView, setCurrentView] = useState<View>('products');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const { user, isLoading, login, register, logout } = useAuth();
  const { cart, addToCart, removeFromCart, updateQuantity, clearCart, getTotalItems, getTotalPrice } = useCart();
  const { orders, createOrder } = useOrders(user);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentView('product-detail');
  };

  const handleBackToProducts = () => {
    setSelectedProduct(null);
    setCurrentView('products');
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product);
  };

  const handleAuthClick = () => {
    if (user) {
      setCurrentView('orders');
    } else {
      setIsAuthModalOpen(true);
    }
  };

  const handleCheckout = () => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    setIsCartOpen(false);
    setIsCheckoutModalOpen(true);
  };

  const handleOrderComplete = async (shippingAddress: any) => {
    if (!user) return;
    
    try {
      const order = await createOrder(cart, shippingAddress);
      clearCart();
      setCurrentView('orders');
      
      // Show success message
      alert(`Order #${order.id} placed successfully!`);
    } catch (error) {
      console.error('Failed to create order:', error);
      alert('Failed to place order. Please try again.');
    }
  };

  const handleOrderClick = (order: Order) => {
    setSelectedOrder(order);
  };

  const handleLogout = () => {
    logout();
    setCurrentView('products');
    setIsAuthModalOpen(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header
        cartItemsCount={getTotalItems()}
        user={user}
        onCartClick={() => setIsCartOpen(true)}
        onAuthClick={handleAuthClick}
        onSearchChange={setSearchQuery}
        searchQuery={searchQuery}
      />

      <main>
        {currentView === 'products' && (
          <ProductGrid
            products={products}
            onAddToCart={handleAddToCart}
            onProductClick={handleProductClick}
            searchQuery={searchQuery}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        )}

        {currentView === 'product-detail' && selectedProduct && (
          <ProductDetail
            product={selectedProduct}
            onBack={handleBackToProducts}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentView === 'orders' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-3xl font-bold text-gray-900">My Account</h1>
              <button
                onClick={() => setCurrentView('products')}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Continue Shopping
              </button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Info</h3>
                  <div className="space-y-2">
                    <p><span className="font-medium">Name:</span> {user?.name}</p>
                    <p><span className="font-medium">Email:</span> {user?.email}</p>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="w-full mt-4 bg-red-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-red-700 transition-colors"
                  >
                    Sign Out
                  </button>
                </div>
              </div>
              
              <div className="lg:col-span-3">
                <OrderHistory
                  orders={orders}
                  onOrderClick={handleOrderClick}
                />
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modals */}
      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={handleCheckout}
        total={getTotalPrice()}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={login}
        onRegister={register}
        user={user}
        onLogout={handleLogout}
      />

      <CheckoutModal
        isOpen={isCheckoutModalOpen}
        onClose={() => setIsCheckoutModalOpen(false)}
        items={cart}
        total={getTotalPrice()}
        user={user}
        onOrderComplete={handleOrderComplete}
      />
    </div>
  );
}

export default App;