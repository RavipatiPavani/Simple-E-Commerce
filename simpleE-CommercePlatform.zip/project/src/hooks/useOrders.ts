import { useState, useEffect } from 'react';
import { Order, CartItem, Address, User } from '../types';

export const useOrders = (user: User | null) => {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (user) {
      const savedOrders = localStorage.getItem(`orders_${user.id}`);
      if (savedOrders) {
        setOrders(JSON.parse(savedOrders));
      }
    }
  }, [user]);

  const createOrder = async (items: CartItem[], shippingAddress: Address): Promise<Order> => {
    if (!user) {
      throw new Error('User must be logged in to create an order');
    }

    const total = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    
    const newOrder: Order = {
      id: Date.now(),
      userId: user.id,
      items: items,
      total: total,
      status: 'pending',
      createdAt: new Date().toISOString(),
      shippingAddress: shippingAddress
    };

    const updatedOrders = [...orders, newOrder];
    setOrders(updatedOrders);
    localStorage.setItem(`orders_${user.id}`, JSON.stringify(updatedOrders));

    return newOrder;
  };

  const getOrderById = (orderId: number): Order | undefined => {
    return orders.find(order => order.id === orderId);
  };

  return {
    orders,
    createOrder,
    getOrderById
  };
};